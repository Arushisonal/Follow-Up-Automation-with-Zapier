# Automation Setup Guide

## 1. Google Form Setup

1. Create a new Google Form
2. Add the following fields:
   - Venue Name (Short answer)
   - Contact Number (Short answer)
   - City (Short answer)
   - Sport (Multiple choice)
3. Configure form settings:
   - Enable email notifications
   - Collect email addresses
   - Limit to 1 response per person

## 2. Zapier Automation Setup

### Step 1: Create New Zap
1. Log in to Zapier
2. Click "Create Zap"
3. Name it "Venue Onboarding Follow-up"

### Step 2: Configure Trigger
1. Select "Google Forms" as the trigger app
2. Choose "New Form Submission" as the trigger event
3. Connect your Google account
4. Select the Venue Onboarding form
5. Test the trigger with a sample submission

### Step 3: Configure WhatsApp Action
1. Add action step
2. Select "WhatsApp" as the action app
3. Choose "Send Message" as the action event
4. Configure message template:
```
Hello! Thank you for your interest in partnering with Sportomic.

We received your venue details:
Venue: {{Venue Name}}
City: {{City}}
Sport: {{Sport}}

Our team will review your application and get back to you within 24 hours.

Best regards,
Team Sportomic
```

### Step 4: Configure Google Sheets Action
1. Add another action step
2. Select "Google Sheets" as the action app
3. Choose "Create Spreadsheet Row" as the action event
4. Configure spreadsheet columns:
   - Timestamp
   - Venue Name
   - Contact Number
   - City
   - Sport
   - Status

## 3. Testing the Automation

1. Submit a test entry through the Google Form
2. Verify that:
   - WhatsApp message is sent to the contact number
   - Entry is logged in Google Sheets
   - All data is correctly formatted

## 4. Monitoring and Maintenance

1. Set up Zapier notifications for failed runs
2. Regularly check the Google Sheet for new entries
3. Monitor WhatsApp message delivery status
4. Update message template as needed

## 5. Troubleshooting

Common issues and solutions:
1. WhatsApp message not sending
   - Verify phone number format
   - Check WhatsApp Business API connection
2. Google Sheets not updating
   - Verify spreadsheet permissions
   - Check Zapier connection status
3. Form submission not triggering
   - Verify form settings
   - Check Zapier trigger configuration 