# Sportomic Venue Onboarding Automation

This project implements an automated follow-up system for venue leads using Google Forms, Zapier, and WhatsApp integration.

## Project Overview

The automation flow:
1. Venue owners submit their information through a Google Form
2. Zapier triggers on new form submission
3. Automated WhatsApp message is sent to the venue contact
4. Submission details are logged in Google Sheets

## Components

### 1. Google Form
- **Form Link**: [Venue Onboarding Form](https://docs.google.com/forms/d/1q-dA6_MJ6AbPazV36vD6_fPB47in_k1MftOkK2TYUqc/edit)
- **Fields**:
  - Venue Name
  - Contact Number
  - City
  - Sport

### 2. Zapier Automation
- Trigger: New Google Form submission
- Actions:
  - Send WhatsApp message
  - Log to Google Sheets

### 3. Documentation
- `automation_setup.md`: Detailed setup instructions
- `flowchart.drawio`: Visual representation of the automation flow

## Setup Instructions

1. Create a Google Form with the required fields
2. Set up Zapier account and create new Zap
3. Configure Google Sheets for logging
4. Test the automation with sample submissions

## Testing

To test the automation:
1. Submit a test entry through the Google Form
2. Verify WhatsApp message delivery
3. Check Google Sheets for logged entry

## Deliverables

- [x] Google Form with test submissions
- [x] Automation setup documentation
- [x] Flowchart visualization
- [x] Demo video walkthrough 